# Insieme di certificazione del linker anatomico (inglese) — 8 ottobre 2026

Due schede da etichettare, ciascuna in due copie identiche con ordine diverso (`annotator_A.csv` per il primo radiologo, `annotator_B.csv` per il secondo):

| Cartella | Testi | Righe |
|---|---|---|
| `certificazione_iux` | Indiana University Chest X-ray (referti radiologici veri, inglese, pubblici) | 518 |
| `certificazione_mc` | MultiCaRe (case report clinici con imaging, inglese, CC BY) | 1.150 |

Le frasi vengono da referti **mai usati** durante lo sviluppo (seme 20261009, esclusi i referti dei campioni già letti). Ogni riga è una menzione di un referto diverso.

## Come si etichetta

Le regole sono quelle di `docs/gold_set_protocollo.md` (sezione "Regole di etichettatura"):
- `structure`: un id da `valid_structures.txt`, oppure `NONE_IN_CLASSES`, `NOT_ANATOMY`, `AMBIGUOUS`;
- `relation`: `equal`, `part_of`, `contour_of`, `approx`;
- `side_in_text`: `dx`, `sn`, `bil`, `none`;
- `note`: solo per i dubbi.

Regole approvate da ricordare:
- una struttura nominata solo come modificatore di una misura o di una funzione ("heart rate", "liver function tests", "brain activity") è `NOT_ANATOMY`;
- "hip" senza "bone" è la regione o l'articolazione: verso l'osso dell'anca la relazione è `approx`;
- un organo nominato in una malattia o in una procedura ("prostate cancer", "liver biopsy") è la struttura.

**Una decisione ancora aperta.** Il lato: oggi il protocollo dice che il lato si legge nella frase, non nel resto del referto. Se il radiologo legge il lato dal nome dell'esame ("RM ginocchio destro: ... femore"), lo scriva nella colonna `note` con "lato dall'esame". Così si decide insieme se il sistema può prendere il lato dal nome dell'esame.

## Cosa non fare

- Non guardare le etichette dell'altro radiologo né i risultati del sistema.
- Non aprire `items.jsonl` (resta allo sviluppo: contiene la divisione calibrazione/test).
- Non discutere i casi durante l'etichettatura: i disaccordi vanno al terzo revisore.

Restituire le due schede compilate (`annotator_A.csv`, `annotator_B.csv`) per cartella.
